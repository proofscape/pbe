/*
 * This is a stub file. Its actual contents are generated at build time,
 * by the `genabout.js` loader.
 */
export const softwareTableRows = '';
